// Dodajte stvarne projekte u ovaj niz. Prazan niz prikazuje pripremljen placeholder.
// Oblik jednog projekta:
// {
//   title: 'Naziv projekta',
//   description: 'Kratak opis projekta.',
//   image: 'assets/ime-fotografije.webp', // opciono
//   imageAlt: 'Opis sadržaja fotografije',
//   url: 'https://...', // opciono; bez URL-a nema linka na drugu stranicu
//   category: 'Edukacija', // opciono
// }
export const projects = [];
